/*
  D_NUMERI.cpp - Libreria per gestire la visualizzazione
  dei numeri da 1 a 6 sul display
  Autore : Maurizio Mainardi
  Versione : 1.1 
*/

// Inclusione della libreria
#include "D_NUMERI1.h"

// Generazione numeri sul display
void D_NUMERI1::d_acceso(int A, int B, int C, int D, int E, int F, int G, int valore) {
  switch (valore) {
    case 1: 
      digitalWrite(A,HIGH);   // A
      digitalWrite(B,LOW);    // B
      digitalWrite(C,LOW);    // C
      digitalWrite(D,HIGH);   // D
      digitalWrite(E,HIGH);   // E
      digitalWrite(F,HIGH);   // F
      digitalWrite(G,HIGH);   // G
      break;
    case 2:
      digitalWrite(A,LOW);    // A
      digitalWrite(B,LOW);    // B
      digitalWrite(C,HIGH);   // C
      digitalWrite(D,LOW);    // D
      digitalWrite(E,LOW);    // E
      digitalWrite(F,HIGH);   // F
      digitalWrite(G,LOW);    // G
      break;
    case 3:
      digitalWrite(A,LOW);    // A
      digitalWrite(B,LOW);    // B
      digitalWrite(C,LOW);    // C
      digitalWrite(D,LOW);    // D
      digitalWrite(E,HIGH);   // E
      digitalWrite(F,HIGH);   // F
      digitalWrite(G,LOW);    // G
      break;
    case 4:
      digitalWrite(A,HIGH);   // A
      digitalWrite(B,LOW);    // B
      digitalWrite(C,LOW);    // C
      digitalWrite(D,HIGH);   // D
      digitalWrite(E,HIGH);   // E
      digitalWrite(F,LOW);    // F
      digitalWrite(G,LOW);    // G
      break;
    case 5:
      digitalWrite(A,LOW);    // A
      digitalWrite(B,HIGH);   // B
      digitalWrite(C,LOW);    // C
      digitalWrite(D,LOW);    // D
      digitalWrite(E,HIGH);   // E
      digitalWrite(F,LOW);    // F
      digitalWrite(G,LOW);    // G
      break;
    case 6:
      digitalWrite(A,LOW);    // A
      digitalWrite(B,HIGH);   // B
      digitalWrite(C,LOW);    // C
      digitalWrite(D,LOW);    // D
      digitalWrite(E,LOW);    // E
      digitalWrite(F,LOW);    // F
      digitalWrite(G,LOW);    // G
      break;
  }
}

// Display spento
void D_NUMERI1::d_spento(int A, int B, int C, int D, int E, int F, int G) {
  digitalWrite(A,HIGH);   // A
  digitalWrite(B,HIGH);   // B
  digitalWrite(C,HIGH);   // C
  digitalWrite(D,HIGH);   // D
  digitalWrite(E,HIGH);   // E
  digitalWrite(F,HIGH);   // F
  digitalWrite(G,HIGH);   // G
}

