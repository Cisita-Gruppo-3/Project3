/*
  D_NUMERI1.h - Header per gestire la libreria per la visualizzazione
  dei numeri da 1 a 6 sul display
  Autore : Maurizio Mainardi
  Versione : 1.0 
*/


#ifndef D_NUMERI1_H
#define D_NUMERI1_H

#include "Arduino.h"

/*
  Alle funzioni per la generazione dei numeri sul display vengono passati 
  i pin di Arduino a cui sono collegati i pin del display e non ritornano nessun valore.
*/
class D_NUMERI1
{
   public:
      // Generazione dei numeri sul display
      void d_acceso(int A, int B, int C, int D, int E, int F, int G, int valore);
      // Display spento
      void d_spento(int A, int B, int C, int D, int E, int F, int G);
};

#endif
