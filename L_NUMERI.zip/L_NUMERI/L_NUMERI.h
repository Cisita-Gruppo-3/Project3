/*
  L_NUMERI.h - Header per gestire la libreria per la visualizzazione
  dei numeri da 1 a 6 in binario con accensione dei led
  Autore : Maurizio Mainardi
  Versione : 1.0 
*/


#ifndef L_NUMERI_H
#define L_NUMERI_H

#include "Arduino.h"

/*
  Alle funzioni per la generazione dei numeri sui led vengono passati 
  i pin di Arduino a cui sono collegati i led e non ritornano nessun valore.
*/
class L_NUMERI
{
   public:
      // Generazione del numero 1
      void l_uno(int A, int B, int C);
      // Generazione del numero 2
      void l_due(int A, int B, int C);
      // Generazione del numero 3
      void l_tre(int A, int B, int C);
      // Generazione del numero 4
      void l_quattro(int A, int B, int C);
      // Generazione del numero 5
      void l_cinque(int A, int B, int C);
      // Generazione del numero 6
      void l_sei(int A, int B, int C);
      // Led spenti
      void l_spento(int A, int B, int C);
};

#endif
