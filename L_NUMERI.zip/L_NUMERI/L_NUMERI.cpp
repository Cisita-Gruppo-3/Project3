/*
  L_NUMERI.cpp - Libreria per gestire la visualizzazione
  dei numeri da 1 a 6 in binario con accensione dei led
  Autore : Maurizio Mainardi
  Versione : 1.0 
*/

// Inclusione della libreria
#include "L_NUMERI.h"

// Generazione numero 1 in binario
void L_NUMERI::l_uno(int A, int B, int C) {
  digitalWrite(A,LOW);    // 3
  digitalWrite(B,LOW);    // 2
  digitalWrite(C,HIGH);   // 1
}

// Generazione numero 2 in binario
void L_NUMERI::l_due(int A, int B, int C) {
  digitalWrite(A,LOW);    // 3
  digitalWrite(B,HIGH);   // 2
  digitalWrite(C,LOW);    // 1
}

// Generazione numero 3 in binario
void L_NUMERI::l_tre(int A, int B, int C) {
  digitalWrite(A,LOW);    // 3
  digitalWrite(B,HIGH);   // 2
  digitalWrite(C,HIGH);   // 1
}

// Generazione numero 4 in binario
void L_NUMERI::l_quattro(int A, int B, int C) {
  digitalWrite(A,HIGH);   // 3
  digitalWrite(B,LOW);    // 2
  digitalWrite(C,LOW);    // 1
}

// Generazione numero 5 in binario
void L_NUMERI::l_cinque(int A, int B, int C) {
  digitalWrite(A,HIGH);   // 3
  digitalWrite(B,LOW);    // 2
  digitalWrite(C,HIGH);   // 1
}

// Generazione numero 6 in binario
void L_NUMERI::l_sei(int A, int B, int C) {
  digitalWrite(A,HIGH);   // 3
  digitalWrite(B,HIGH);   // 2
  digitalWrite(C,LOW);    // 1
}

// Led spenti
void L_NUMERI::l_spento(int A, int B, int C) {
  digitalWrite(A,LOW);   // 3
  digitalWrite(B,LOW);   // 2
  digitalWrite(C,LOW);   // 1
}

